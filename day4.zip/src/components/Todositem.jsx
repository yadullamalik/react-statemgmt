export const Todositem=({title,status,id})=>{
    return <div>
        {title} - {status ? "Done" : "Not Done"}
    </div>
}