import { useState } from "react";
import {v4 as uuid} from "uuid";
import { GroceryInput } from "./GroceryInput";
import { GroceryList } from "./GroceryList";
import "./Grocery.css"

export const Grocery=()=>{
    const [grocery,setGrocery]=useState([]);
    const Click=(data)=>{
        const payload={
            title:data,
            id:uuid(),
            status:false
        }
        setGrocery([...grocery,payload])
    }
    const a=(id)=>{
        const items=grocery.map((item)=>item.id ? {...item,status:!item.states} : item)
        setGrocery(items)
    }
    const del=(id)=>{
        const items=grocery.filter(item=>{
            return item.id!=id
        })
        setGrocery(items)
    }
    return (
        <div>
            <h1 id="h1">Groceries</h1>
            <GroceryInput have={Click}/>
            {grocery.map(item=>{
                return <GroceryList title={item.title} id={item.id} status={item.states} a={a} del={del} />
            })}
        </div>
    )
}