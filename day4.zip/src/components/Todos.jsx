import { useState } from "react"
import { Todosinput } from "./Todosinput"
import { Todositem } from "./Todositem";
import {v4 as uuid } from "uuid";

export const Todos=()=>{
    const [todos,setTodos] =useState([]);
    const handleClick=(text)=>{
        const payload={
            title: text,
            id: uuid(),
            status: false,
        };
        setTodos([...todos, payload]);
    };

    return <div>
        <Todosinput handleClick={handleClick} />
        {todos.map((e)=>{
            return <Todositem key={e.id} title={e.title} status={e.status} />;
        })}
    </div>
}