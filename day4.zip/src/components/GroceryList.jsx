import "./Grocery.css"

export const GroceryList=({title,id,status,a,del})=>{
    return (
        <div className="div"><span className="p">{title} - </span>
        <button className="btn" onClick={()=>{
            a(id)
        }}>{status ? "True" : "False"}</button>
        <button className="btn" onClick={()=>{
            del(id)
        }}>Remove</button>
        </div>
    )
}