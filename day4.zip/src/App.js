import './App.css';
import { useState } from 'react';
import { Grocery } from './components/Grocery';
// import { Todos } from './components/Todos';

function App() {
  return (
    <div className="App">
      {/* <Todos /> */}
      <Grocery />
    </div>
  );
}

export default App;
